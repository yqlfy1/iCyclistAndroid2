package com.example.icyclist_android2

class DiscoveryStatus(val id: Int, val title: String, val content: String)