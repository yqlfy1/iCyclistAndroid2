package com.example.icyclist_android2

import android.content.Intent
import android.os.Bundle
import android.os.SystemClock
import android.view.View
import android.widget.Button
import android.widget.Chronometer
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AlertDialog


class sport : AppCompatActivity() {
    private lateinit var timerChronometer: Chronometer
    private lateinit var startButton: Button
    private lateinit var pauseButton: Button
    private lateinit var continueButton: Button
    private var isPaused = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_sport)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        timerChronometer = findViewById(R.id.timerChronometer)
        startButton = findViewById(R.id.startButton)
        pauseButton = findViewById(R.id.pauseButton)
        continueButton = findViewById(R.id.continueButton)

        startButton.setOnClickListener {
            if (!isPaused) {
                startTimer()
            }
        }

        pauseButton.setOnClickListener {
            togglePauseResumeTimer()
        }

        pauseButton.setOnLongClickListener {
            showConfirmDialog()
            true // 返回true表示点击事件已消费
        }

        continueButton.setOnClickListener {
            resumeTimer()
        }

        //跳转按钮
        val spbutton1 = findViewById<Button>(R.id.spbutton1)
        val spbutton3 = findViewById<Button>(R.id.spbutton3)
        spbutton1.setOnClickListener {
            val intent1 = Intent(this,MainActivity::class.java)
            startActivity(intent1)
        }
        spbutton3.setOnClickListener {
            val intent2 = Intent(this,discovery::class.java)
            startActivity(intent2)
        }
    }

    private fun startTimer() {
        timerChronometer.start()
        isPaused = false
    }

    private fun togglePauseResumeTimer() {
        if (!isPaused) {
            pauseTimer()
        } else {
            resumeTimer()
        }
    }

    private fun pauseTimer() {
        timerChronometer.stop()
        isPaused = true
    }

    private fun resumeTimer() {
        timerChronometer.start()
        isPaused = false
    }

    private fun showConfirmDialog() {
        AlertDialog.Builder(this@sport)
            .setMessage("确定要结束本次骑行吗？")
            .setPositiveButton("确定") { dialog, which ->
                resetTimer()
            }
            .setNegativeButton("取消", null)
            .show()
    }

    private fun resetTimer() {
        timerChronometer.base = SystemClock.elapsedRealtime()
        timerChronometer.stop()
    }

    override fun onDestroy() {
        super.onDestroy()
    }
}