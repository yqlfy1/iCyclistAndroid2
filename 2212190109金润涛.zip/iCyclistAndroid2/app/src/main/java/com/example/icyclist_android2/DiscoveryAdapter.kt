package com.example.icyclist_android2

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class DiscoveryAdapter (private var statuses: List<DiscoveryStatus>) : RecyclerView.Adapter<DiscoveryAdapter.StatusViewHolder>() {

    // 提供一个方法来更新数据
    fun updateList(newStatuses: List<DiscoveryStatus>) {
        statuses = newStatuses
        notifyDataSetChanged() // 通知数据集改变
    }

    class StatusViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var titleTextView: TextView = itemView.findViewById(R.id.titleTextView)
        var contentTextView: TextView = itemView.findViewById(R.id.contentTextView)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): StatusViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.status_item, parent, false)
        return StatusViewHolder(view)
    }

    override fun onBindViewHolder(holder: StatusViewHolder, position: Int) {
        val status = statuses[position]
        holder.titleTextView.text = status.title
        holder.contentTextView.text = status.content
    }

    override fun getItemCount() = statuses.size
}