package com.example.icyclist_android2

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.widget.Toast
import android.content.ContentValues

class DiscoveryDataBase(val context: Context, name: String, version: Int) : SQLiteOpenHelper(context, name, null, version) {

    private val createStatuses = "create table Statuses (" +
            "id integer primary key autoincrement," +
            "title text," +  // 用于存储中文标题
            "content text)"

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(createStatuses)
        Toast.makeText(context, "Create succeeded", Toast.LENGTH_SHORT).show()
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS Statuses")
        onCreate(db)
    }

    // 插入数据
    fun insertStatus(values: ContentValues): Boolean {
        val db = writableDatabase
        val result = db.insert("Statuses", null, values)
        db.close()
        return result != -1L
    }

    // 查询数据
    fun getStatuses(): List<DiscoveryStatus> {
        val statuses = mutableListOf<DiscoveryStatus>()
        val db = readableDatabase
        val selectQuery = "SELECT id, title, content FROM Statuses"
        val cursor = db.rawQuery(selectQuery, null)

        if (cursor.moveToFirst()) {
            do {
                val idIndex = cursor.getColumnIndex("id")
                val titleIndex = cursor.getColumnIndex("title")
                val contentIndex = cursor.getColumnIndex("content")

                // 检查索引值是否有效
                if (idIndex != -1 && titleIndex != -1 && contentIndex != -1) {
                    val id = cursor.getInt(idIndex)
                    val title = cursor.getString(titleIndex)
                    val content = cursor.getString(contentIndex)
                    statuses.add(DiscoveryStatus(id, title, content))
                }
            } while (cursor.moveToNext())
        }
        cursor.close()
        db.close()
        return statuses
    }
}