package com.example.icyclist_android2

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class UserDatabase(context: Context, name: String, version: Int) : SQLiteOpenHelper(context, name, null, version) {

    private val CREATE_USERS_TABLE = """
        CREATE TABLE Users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nickname TEXT NOT NULL,
            password TEXT NOT NULL
        )
    """.trimIndent()

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(CREATE_USERS_TABLE)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS Users")
        onCreate(db)
    }

    fun insertUser(nickname: String, password: String) {
        val db = writableDatabase
        val values = ContentValues().apply {
            put("nickname", nickname)
            put("password", password)
        }
        db.insert("Users", null, values)
    }

    fun getUser(nickname: String): User? {
        val db = readableDatabase
        val selectQuery = "SELECT * FROM Users WHERE nickname=?"
        val cursor = db.rawQuery(selectQuery, arrayOf(nickname))

        if (cursor.moveToFirst()) {
            val idIndex = cursor.getColumnIndex("id")
            val nicknameIndex = cursor.getColumnIndex("nickname")
            val passwordIndex = cursor.getColumnIndex("password")

            // 检查索引值是否有效
            if (idIndex != -1 && nicknameIndex != -1 && passwordIndex != -1) {
                val id = cursor.getInt(idIndex)
                val nickname = cursor.getString(nicknameIndex)
                val password = cursor.getString(passwordIndex)
                cursor.close()
                return User(id, nickname, password)
            }
        }
        cursor.close()
        return null
    }
}

data class User(val id: Int, val nickname: String, val password: String)