package com.example.icyclist_android2

import android.content.ContentValues
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class discovery : AppCompatActivity() {
    private lateinit var discoveryRecyclerView: RecyclerView
    private lateinit var discoveryAdapter: DiscoveryAdapter
    private lateinit var discoveryDatabase: DiscoveryDataBase

    companion object {
        const val REQUEST_CODE = 1
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_discovery)

        discoveryDatabase = DiscoveryDataBase(this, "discovery.db", 1)
        discoveryRecyclerView = findViewById(R.id.discoveryRecyclerView)
        discoveryRecyclerView.layoutManager = LinearLayoutManager(this)

        val discoveryStatuses = discoveryDatabase.getStatuses()
        discoveryAdapter = DiscoveryAdapter(discoveryStatuses)
        discoveryRecyclerView.adapter = discoveryAdapter

        val addButton = findViewById<Button>(R.id.addButton)
        addButton.setOnClickListener {
            val intent = Intent(this, insert::class.java)
            startActivityForResult(intent, REQUEST_CODE)
        }

        // 跳转按钮
        val disbutton1 = findViewById<Button>(R.id.disbutton1)
        val disbutton2 = findViewById<Button>(R.id.disbutton2)
        disbutton1.setOnClickListener {
            val intent1 = Intent(this, MainActivity::class.java)
            startActivity(intent1)
        }
        disbutton2.setOnClickListener {
            val intent2 = Intent(this, sport::class.java)
            startActivity(intent2)
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_CODE && resultCode == RESULT_OK) {
            // 刷新 RecyclerView
            refreshRecyclerView()
        }
    }

    private fun refreshRecyclerView() {
        val statuses = discoveryDatabase.getStatuses()
        discoveryAdapter.updateList(statuses)
    }
}