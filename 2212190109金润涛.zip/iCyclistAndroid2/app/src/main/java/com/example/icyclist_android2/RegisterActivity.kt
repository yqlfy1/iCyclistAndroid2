package com.example.icyclist_android2

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class RegisterActivity : AppCompatActivity() {

    private lateinit var nicknameEditText: EditText
    private lateinit var passwordEditText: EditText
    private lateinit var registerButton: Button
    private lateinit var userDatabase: UserDatabase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        nicknameEditText = findViewById(R.id.regnicknameEditText)
        passwordEditText = findViewById(R.id.regpasswordEditText)
        registerButton = findViewById(R.id.registerButton)
        userDatabase = UserDatabase(this, "user.db", 1)

        registerButton.setOnClickListener {
            val nickname = nicknameEditText.text.toString().trim()
            val password = passwordEditText.text.toString().trim()
            registerUser(nickname, password)
        }
    }

    private fun registerUser(nickname: String, password: String) {
        if (nickname.isNotEmpty() && password.isNotEmpty()) {
            userDatabase.insertUser(nickname, password)
            Toast.makeText(this, "注册成功", Toast.LENGTH_SHORT).show()
            finish()  // 关闭注册页面，返回登录页面
        } else {
            Toast.makeText(this, "昵称和密码不能为空", Toast.LENGTH_SHORT).show()
        }
    }
}