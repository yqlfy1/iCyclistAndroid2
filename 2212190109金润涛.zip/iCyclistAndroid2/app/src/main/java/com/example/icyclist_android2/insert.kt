package com.example.icyclist_android2

import android.content.ContentValues
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class insert : AppCompatActivity() {

    private lateinit var titleEditText: EditText
    private lateinit var contentEditText: EditText
    private lateinit var publishButton: Button
    private lateinit var discoveryDatabase: DiscoveryDataBase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_insert)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        titleEditText = findViewById(R.id.titleEditText)
        contentEditText = findViewById(R.id.contentEditText)
        publishButton = findViewById(R.id.publishButton)
        discoveryDatabase = DiscoveryDataBase(this, "discovery.db", 1)

        publishButton.setOnClickListener {
            val title = titleEditText.text.toString().trim()
            val content = contentEditText.text.toString().trim()
            if (title.isNotEmpty() && content.isNotEmpty()) {
                insertStatus(title, content)
                setResult(RESULT_OK)
                finish()
            } else {
                Toast.makeText(this, "标题和内容不能为空", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun insertStatus(title: String, content: String) {
        val values = ContentValues().apply {
            put("title", title)
            put("content", content)
        }
        val success = discoveryDatabase.insertStatus(values)
        if (success) {
            Log.d("DatabaseContent", "Insert successful")
            setResult(RESULT_OK)
            finish()
        } else {
            Log.d("DatabaseContent", "Insert failed")
            Toast.makeText(this, "插入数据失败", Toast.LENGTH_SHORT).show()
        }
    }
}