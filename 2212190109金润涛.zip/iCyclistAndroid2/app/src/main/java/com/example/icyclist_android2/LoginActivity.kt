package com.example.icyclist_android2

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class LoginActivity : AppCompatActivity() {

    private lateinit var nicknameEditText: EditText
    private lateinit var passwordEditText: EditText
    private lateinit var loginButton: Button
    private lateinit var registerButton: Button
    private lateinit var userDatabase: UserDatabase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        nicknameEditText = findViewById(R.id.nicknameEditText)
        passwordEditText = findViewById(R.id.passwordEditText)
        loginButton = findViewById(R.id.loginButton)
        registerButton = findViewById(R.id.registerButton)
        userDatabase = UserDatabase(this, "user.db", 1)

        loginButton.setOnClickListener {
            val nickname = nicknameEditText.text.toString().trim()
            val password = passwordEditText.text.toString().trim()
            loginUser(nickname, password)
        }

        registerButton.setOnClickListener {
            // 跳转到注册页面
            val intent = Intent(this, RegisterActivity::class.java)
            startActivity(intent)
        }
    }

    private fun loginUser(nickname: String, password: String) {
        val user = userDatabase.getUser(nickname)
        Log.d("112233","$user")
        if (user != null && user.password == password) {
            val intent = Intent(this, MainActivity::class.java)
            intent.putExtra("USER_ID", user.id)
            intent.putExtra("USER_NICKNAME", user.nickname)
            startActivity(intent)
            finish()
        } else {
            Toast.makeText(this, "用户名或密码错误", Toast.LENGTH_SHORT).show()
        }
    }
}